Semantics Based Interpreter
===========================

A SOS-based interpreted in OCaml.  Based upon the lecture notes for the class
Semantics of Programming Languages, Computer Science Tripos, Part 1B, 2014–15
Peter Sewell, Computer Laboratory, University of Cambridge
